from flask import Flask, render_template, send_file
import matplotlib.pyplot as plt
import io

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/download-graph')
def download_graph():
    # Gerar gráfico simples
    plt.figure()
    plt.plot([1, 2, 3, 4], [10, 20, 25, 30])
    plt.title('Gráfico de Exemplo')

    # Guardar em memória
    img = io.BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    plt.close()

    return send_file(img, mimetype='image/png', as_attachment=True, download_name='grafico.png')

if __name__ == '__main__':
    app.run(debug=True)
